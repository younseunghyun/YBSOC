__author__ = 'jack'
from multiprocessing import Process, Queue, Pool
from urlCrawler import blogUrlC 
from dataSaver import dataSaver

 if __name__ =='__main__'   
    crawler.ini_date = '2013,1,1'
    crawler.e_date = '2014,10,7'
    crawler.thread_number = 10
    crawler.contextGather = blogContextGather
    crawler.urlGather = blogUrl
    crawler.dataSaver = dataSaver.dataSaving
    print(crawler)
    crawler.run()




    





